#!/usr/bin/bash
g++ -o kostky src/main.cpp
